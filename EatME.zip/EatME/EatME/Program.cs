﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EatME
{
    class Program
    {
        static void Main(string[] args)
        {
            PlayTheGame play = new PlayTheGame();
            play.WantPlay();
        }
    }
}

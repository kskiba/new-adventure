﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EatME
{
    class IntroduceYourself
    {
        public string name;
        public int sign, colorIndex;
        public char pawnPattern;
        List<ConsoleColor> WhichColor;
        Messages message = new Messages();
            
        public void Name()
        {
            Console.Write("What's your name? ");
            GetColor();
            name = Console.ReadLine();
            Console.WriteLine();
            Console.ResetColor();
        }
        public void Color()
        {
            Console.SetCursorPosition(0, 2);
            Console.WriteLine("Choose color of your name and pawn");
            Console.WriteLine("1- standard");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("2- cyan");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("3- red");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("4- yellow");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("5- magenta");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("6- green");
            Console.ResetColor();
            Console.WriteLine();
            while (true)
            {
                try { colorIndex = int.Parse(Console.ReadLine()); }
                catch { Console.WriteLine("Wrong value. Try again."); continue; }
                if (colorIndex > 0 && colorIndex < 7) break;
                else
                {
                    System.Console.WriteLine("Wrong value. Try again");
                }
            }

            WhichColor = new List<ConsoleColor> { ConsoleColor.Gray, ConsoleColor.Cyan, ConsoleColor.Red, ConsoleColor.Yellow, ConsoleColor.Magenta, ConsoleColor.Green };
            Console.WriteLine();
        }
        public void GetColor()
        {
            int i = colorIndex - 1;
            Console.ForegroundColor = WhichColor[i];
        }
        public void GetNameInColor()
        {
            GetColor();
            Console.WriteLine(name);
            Console.ResetColor();
        }
        public void Sign()
        {
            Console.WriteLine("Choose pattern of your pawn");
            Console.Write("1- "); GetColor(); Console.WriteLine((char)(1)); Console.ResetColor();
            Console.Write("2- "); GetColor(); Console.WriteLine((char)(3)); Console.ResetColor();
            Console.Write("3- "); GetColor(); Console.WriteLine((char)(14)); Console.ResetColor();
            Console.Write("4- "); GetColor(); Console.WriteLine((char)(4)); Console.ResetColor();
            Console.WriteLine();

            while (true)
            {
                try { sign = int.Parse(Console.ReadLine()); }
                catch { Console.WriteLine("Wrong value. Try again."); continue; }
                if (sign > 0 && sign < 5) break;
                else
                {
                    System.Console.WriteLine("Wrong value. Try again");
                }
            }

            if (sign == 1) pawnPattern = (char)(1);
            if (sign == 2) pawnPattern = (char)(3);
            if (sign == 3) pawnPattern = (char)(14);
            if (sign == 4) pawnPattern = (char)(4);

            Console.Clear();
        }
        public char GetPawnPattern()
        {
            return pawnPattern;
        }
        public void GetPawnPatternInColor()
        {
            GetColor();
            Console.WriteLine(pawnPattern);
            Console.ResetColor();
//            return pawnPattern;
        }
    }
}

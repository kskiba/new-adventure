﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EatME
{
    class BestPlayersList
    {
        public void BestPlayers()
        {
            IntroduceYourself playerName = new IntroduceYourself();
            PlayTheGame playerTime = new PlayTheGame();

            var BestTime = new List<Action> { playerName.GetNameInColor, playerTime.Time };
            
            for(int i = 0; i < 10; i++)
            {
                
            }


            //public string Name;
            //public byte Age;
            //Bar[] BarArr = new Bar[2];
            //BarArr[0].Name = "Janusz Kowalski";
            //BarArr[0].Age = 52;
            //BarArr[1].Name = "Piotr Nowak";
            //BarArr[1].Age = 18;

            //var slownik = new Dictionary<int, student>();
            //slownik.Add(160741, new student() { NtyRazNaRoku = 2 });
            //    var Student = slownik[160741];
            //Console.WriteLine(Student.NtyRazNaRoku);

            //    var indeksy = slownik.Where(p => p.Key > 160000 && p.Key < 160480)
            //    .Select(p => p.Key);
            //    foreach(var index in indeksy )
            //    {
            //        Console.WriteLine(index);
            //    }
        }
    }
}
